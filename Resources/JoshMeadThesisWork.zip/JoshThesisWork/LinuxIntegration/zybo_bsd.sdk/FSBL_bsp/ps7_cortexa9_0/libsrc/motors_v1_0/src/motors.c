

/***************************** Include Files *******************************/
#include "motors.h"

/************************** Function Definitions ***************************/
static volatile struct motors_regs_t *motors_regs = NULL;

inline void Motors_Set_BaseAddress(uint32_t BaseAddress) {
    motors_regs = (struct motors_regs_t *)(BaseAddress);
}

inline void setMotor(uint8_t sel, uint32_t val) {
    switch(sel) {
	  case 0:
		  motors_regs->motor0 = val;
		  break;
      case 1:
		  motors_regs->motor1 = val;
		  break;
	  case 2:
		  motors_regs->motor2 = val;
		  break;
	  case 3:
		  motors_regs->motor3 = val;
		  break;
	  case 4:
		  motors_regs->motor4 = val;
		  break;
	  default:
	      motors_regs->motor5 = val;
	      break;
	}
}

inline void setMotor0(uint32_t val) {
    motors_regs->motor0 = val;
} 

inline void setMotor1(uint32_t val) {
    motors_regs->motor1 = val;
} 

inline void setMotor2(uint32_t val) {
    motors_regs->motor2 = val;
} 

inline void setMotor3(uint32_t val) {
    motors_regs->motor3 = val;
} 

inline void setMotor4(uint32_t val) {
    motors_regs->motor4 = val;
} 

inline void setMotor5(uint32_t val) {
    motors_regs->motor5 = val;
} 