

/***************************** Include Files *******************************/
#include "MPU_9150.h"

/************************** Function Definitions ***************************/
static volatile struct sensor_regs_t *sensor_regs = NULL;

inline void MPU_Set_BaseAddress(uint32_t BaseAddress) {
    sensor_regs = (struct sensor_regs_t *)(BaseAddress);
}

inline int16_t MPU_Get_Accel_X() {
    return (int16_t)sensor_regs->accel_x;
}

inline int16_t MPU_Get_Accel_Y(){
    return (int16_t)sensor_regs->accel_y;
}

inline int16_t MPU_Get_Accel_Z() {
    return (int16_t)sensor_regs->accel_z;
}

inline int16_t MPU_Get_Temp() {
    return (int16_t)sensor_regs->temp;
}

inline float MPU_Get_Temp_Farenheit() {
    int16_t temperature = sensor_regs->temp;
    return ((((temperature/340.0)+36.53) * 1.8) + 32.0);
}

inline float MPU_Get_Temp_Celsius() {
    int16_t temperature = sensor_regs->temp;
    return ((temperature/340.0)+36.53);
}

inline int16_t MPU_Get_Gyro_X() {
    return (int16_t)sensor_regs->gyro_x;
}

inline int16_t MPU_Get_Gyro_Y() {
    return (int16_t)sensor_regs->gyro_y;
}

inline int16_t MPU_Get_Gyro_Z() {
    return (int16_t)sensor_regs->gyro_z;
}