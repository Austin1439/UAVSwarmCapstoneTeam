

/***************************** Include Files *******************************/
#include "SpektrumRadioController.h"

/************************** Function Definitions ***************************/
static volatile struct control_regs_t *control_regs = NULL;

inline void Controller_Set_BaseAddress(uint32_t BaseAddress) {
    control_regs = (struct control_regs_t *)(BaseAddress);
}

inline uint32_t getThrottle() {
    return (control_regs->reg0 & ZERO_BIT_MASK);
}

inline uint32_t getAile() {
    return ((control_regs->reg0 & ONE_BIT_MASK) >> 1);
}

inline uint32_t getElevation() {
    return (control_regs->reg1 & ZERO_BIT_MASK);
}

inline uint32_t getRudder() {
    return ((control_regs->reg1 & ONE_BIT_MASK) >> 1);
}

inline uint32_t getGear() {
    return (control_regs->reg2 & ZERO_BIT_MASK);
}

inline uint32_t getAux1() {
    return ((control_regs->reg2 & ONE_BIT_MASK) >> 1);
}

inline uint32_t getAux2() {
    return (control_regs->reg3 & ZERO_BIT_MASK);
}