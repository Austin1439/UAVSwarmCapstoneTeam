
#ifndef SPEKTRUMRADIOCONTROLLER_H
#define SPEKTRUMRADIOCONTROLLER_H


/****************** Include Files ********************/
#include "xil_types.h"
#include "xstatus.h"

#define SPEKTRUMRADIOCONTROLLER_S00_AXI_SLV_REG0_OFFSET 0
#define SPEKTRUMRADIOCONTROLLER_S00_AXI_SLV_REG1_OFFSET 4
#define SPEKTRUMRADIOCONTROLLER_S00_AXI_SLV_REG2_OFFSET 8
#define SPEKTRUMRADIOCONTROLLER_S00_AXI_SLV_REG3_OFFSET 12

#ifndef NULL
#define NULL		0
#endif

struct control_regs_t {
  uint32_t reg0;
  uint32_t reg1;
  uint32_t reg2;
  uint32_t reg3
} __attribute__((aligned (8))) ;//__attribute__ ((packed));

typedef volatile struct control_regs_t control_regs_t;


/********* Mask Definitions **********/
#define ZERO_BIT_MASK (0x00000001)
#define ONE_BIT_MASK  (0x00000002)

/**************************** Type Definitions *****************************/
/**
 *
 * Write a value to a SPEKTRUMRADIOCONTROLLER register. A 32 bit write is performed.
 * If the component is implemented in a smaller width, only the least
 * significant data is written.
 *
 * @param   BaseAddress is the base address of the SPEKTRUMRADIOCONTROLLERdevice.
 * @param   RegOffset is the register offset from the base to write to.
 * @param   Data is the data written to the register.
 *
 * @return  None.
 *
 * @note
 * C-style signature:
 * 	void SPEKTRUMRADIOCONTROLLER_mWriteReg(u32 BaseAddress, unsigned RegOffset, u32 Data)
 *
 */
#define SPEKTRUMRADIOCONTROLLER_mWriteReg(BaseAddress, RegOffset, Data) \
  	Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))

/**
 *
 * Read a value from a SPEKTRUMRADIOCONTROLLER register. A 32 bit read is performed.
 * If the component is implemented in a smaller width, only the least
 * significant data is read from the register. The most significant data
 * will be read as 0.
 *
 * @param   BaseAddress is the base address of the SPEKTRUMRADIOCONTROLLER device.
 * @param   RegOffset is the register offset from the base to write to.
 *
 * @return  Data is the data from the register.
 *
 * @note
 * C-style signature:
 * 	u32 SPEKTRUMRADIOCONTROLLER_mReadReg(u32 BaseAddress, unsigned RegOffset)
 *
 */
#define SPEKTRUMRADIOCONTROLLER_mReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))

/************************** Function Prototypes ****************************/
/**
 *
 * Run a self-test on the driver/device. Note this may be a destructive test if
 * resets of the device are performed.
 *
 * If the hardware system is not built correctly, this function may never
 * return to the caller.
 *
 * @param   baseaddr_p is the base address of the SPEKTRUMRADIOCONTROLLER instance to be worked on.
 *
 * @return
 *
 *    - XST_SUCCESS   if all self-test code passed
 *    - XST_FAILURE   if any self-test code failed
 *
 * @note    Caching must be turned off for this function to work.
 * @note    Self test may fail if data memory and device are not on the same bus.
 *
 */
XStatus SPEKTRUMRADIOCONTROLLER_Reg_SelfTest(void * baseaddr_p);
void Controller_Set_BaseAddress(uint32_t BaseAddress);
uint32_t getThrottle();
uint32_t getAile();
uint32_t getElevation();
uint32_t getRudder();
uint32_t getGear();
uint32_t getAux1();
uint32_t getAux2();

#endif // SPEKTRUMRADIOCONTROLLER_H
