
#ifndef MPU_9150_H
#define MPU_9150_H


/****************** Include Files ********************/
#include "xil_types.h"
#include "xstatus.h"

#define MPU_9150_S_AXI_SLV_REG0_OFFSET 0
#define MPU_9150_S_AXI_SLV_REG1_OFFSET 4
#define MPU_9150_S_AXI_SLV_REG2_OFFSET 8
#define MPU_9150_S_AXI_SLV_REG3_OFFSET 12

#ifndef NULL
#define NULL		0
#endif

struct sensor_regs_t {
  int16_t accel_x;
  int16_t accel_y;
  int16_t accel_z;
  int16_t temp;
  int16_t gyro_x;
  int16_t gyro_y;
  int16_t gyro_z;
} __attribute__((aligned (8))) ;//__attribute__ ((packed));

typedef volatile struct sensor_regs_t sensor_regs_t;


/********* Mask Definitions **********/
#define MPU_ACCEL_X_MASK (0x0000FFFFUL)
#define MPU_ACCEL_Y_MASK (0xFFFF0000UL)

#define MPU_ACCEL_Z_MASK (0x0000FFFFUL)
#define MPU_TEMP_MASK    (0xFFFF0000UL)

#define MPU_GYRO_X_MASK  (0x0000FFFFUL)
#define MPU_GYRO_Y_MASK  (0xFFFF0000UL)

#define MPU_GYRO_Z_MASK  (0x0000FFFFUL)


/**************************** Type Definitions *****************************/
/**
 *
 * Write a value to a MPU_9150 register. A 32 bit write is performed.
 * If the component is implemented in a smaller width, only the least
 * significant data is written.
 *
 * @param   BaseAddress is the base address of the MPU_9150device.
 * @param   RegOffset is the register offset from the base to write to.
 * @param   Data is the data written to the register.
 *
 * @return  None.
 *
 * @note
 * C-style signature:
 * 	void MPU_9150_mWriteReg(u32 BaseAddress, unsigned RegOffset, u32 Data)
 *
 */
#define MPU_9150_mWriteReg(BaseAddress, RegOffset, Data) \
  	Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))

/**
 *
 * Read a value from a MPU_9150 register. A 32 bit read is performed.
 * If the component is implemented in a smaller width, only the least
 * significant data is read from the register. The most significant data
 * will be read as 0.
 *
 * @param   BaseAddress is the base address of the MPU_9150 device.
 * @param   RegOffset is the register offset from the base to write to.
 *
 * @return  Data is the data from the register.
 *
 * @note
 * C-style signature:
 * 	u32 MPU_9150_mReadReg(u32 BaseAddress, unsigned RegOffset)
 *
 */
/*#define MPU_9150_mReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))  */
	
#define MPU_9150_mReadReg(BaseAddress, RegOffset) \
 	(*((volatile uint32_t *)((BaseAddress) + (RegOffset))))

/************************** Function Prototypes ****************************/
/**
 *
 * Run a self-test on the driver/device. Note this may be a destructive test if
 * resets of the device are performed.
 *
 * If the hardware system is not built correctly, this function may never
 * return to the caller.
 *
 * @param   baseaddr_p is the base address of the MPU_9150 instance to be worked on.
 *
 * @return
 *
 *    - XST_SUCCESS   if all self-test code passed
 *    - XST_FAILURE   if any self-test code failed
 *
 * @note    Caching must be turned off for this function to work.
 * @note    Self test may fail if data memory and device are not on the same bus.
 *
 */
void MPU_Set_BaseAddress(uint32_t BaseAddress);
int16_t MPU_Get_Accel_X();
int16_t MPU_Get_Accel_Y();
int16_t MPU_Get_Accel_Z();
int16_t MPU_Get_Temp();
float MPU_Get_Temp_Farenheit();
float MPU_Get_Temp_Celsius();
int16_t MPU_Get_Gyro_X();
int16_t MPU_Get_Gyro_Y();
int16_t MPU_Get_Gyro_Z();
XStatus MPU_9150_Reg_SelfTest(void * baseaddr_p);

#endif // MPU_9150_H
