This is the IP/Example project for the Radio Controller. 

The current IP is just out <= in and is subject to change as we move forward with this project.

All user logic is handled at the bottom of the *_AXI vhd file. 

*********************************************************************
DEFAULT PORTS FOR EXAMPLE PROJECT:

	Zybo Pmod Layout Reference:
		
		    Top	
	Left	V G 4 3 2 1  Right
		V G 8 7 6 5

	V- VCC
	G- GND

	Input: Receiver- PMOD JB
		Name		Pmod Ref #	Pin Location
		
		Throttle	1		T20
		Aile		2		U20
		Elev		3		V20
		Rudd		4		W20
		Gear		5		Y18
		Aux1		6		Y19
		Aux2		7		W18

	Output: To Motors/Oscilloscope- PMOD JC
		Name		Pmod Ref #	Pin Location
		
		Throttle	1		V15
		Aile		2		W15
		Elev		3		T11
		Rudd		4		T10
		Gear		5		W14
		Aux1		6		Y14
		Aux2		7		T12


***********************************************************************